package br.csi.avaliadordeprojetos.model.aluno;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

@Entity
@Table(name = "alunos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Schema(description = "Entidade que representa um aluno no sistema")
public class Aluno {

    @Id @GeneratedValue(
            strategy =
                    GenerationType.IDENTITY)
    @Schema(description = "ID do usuário", example = "1")
    private Long id;
    @UuidGenerator
    private UUID uuid;
    @NonNull
    @Schema(description = "Nome do usuário", example = "Felipe")
    private String nome;
    @NonNull
    private String matricula;
    @NonNull
    private String email;
    @Embedded
    @NonNull
    private Endereco endereco;
   /* public Aluno(String nome, String email,
                 String matricula, Endereco endereco){
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
        this.matricula = matricula;
    }*/
}






