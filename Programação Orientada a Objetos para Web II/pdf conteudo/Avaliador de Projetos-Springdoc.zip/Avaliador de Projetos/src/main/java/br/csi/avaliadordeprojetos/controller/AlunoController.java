package br.csi.avaliadordeprojetos.controller;


import br.csi.avaliadordeprojetos.model.aluno.Aluno;
import br.csi.avaliadordeprojetos.service.AlunoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/aluno")
@Tag(name = "Alunos", description = "Path relacionado a operações de alunos")
public class AlunoController {
    private AlunoService service;
    public AlunoController(AlunoService service){
        this.service = service;
    }
    /* http://localhost:8080/avaliador-de-projetos/aluno/listar */
    @GetMapping("/listar")
    public List<Aluno> listar(){
        return this.service.listar();
    }
    /* http://localhost:8080/avaliador-de-projetos/aluno/1 */
    @GetMapping("/{id}")
    @Operation(summary = "Buscar usuário por ID", description = "Retorna um usuário correspondente ao ID fornecido")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuário encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Aluno.class))),
            @ApiResponse(responseCode = "404", description = "Usuário não encontrado", content = @Content)
    })
    public Aluno aluno( @Parameter(description = "ID do usuário a ser buscado") @PathVariable Long id){
        return this.service.getAluno(id);
    }
    /* http://localhost:8080/avaliador-de-projetos/aluno/print-json */
    @PostMapping("/print-json")
    public  void printJSon(@RequestBody String json){
        System.out.println(json);
    }
    /* http://localhost:8080/avaliador-de-projetos/aluno */
    @PostMapping()
    @Operation(summary = "Criar um novo usuário", description = "Cria um novo usuário e o adiciona à lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Usuário criado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Aluno.class))),
            @ApiResponse(responseCode = "400", description = "Dados inválidos fornecidos", content = @Content)
    })
    public void salvar(@RequestBody Aluno aluno){
        this.service.salvar(aluno);
    }
    /* http://localhost:8080/avaliador-de-projetos/aluno */
    @PutMapping
    public void atualizar(@RequestBody Aluno aluno){
        this.service.autalizar(aluno);
    }
    /*  http://localhost:8080/avaliador-de-projetos/aluno/1 */
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id){
        this.service.excluir(id);
    }

    /*
    http://localhost:8080/avaliador-de-projetos/aluno/uuid/edddd513-9ecd-45ac-8387-16256eae723a
    */
    @GetMapping("/uuid/{uuid}")
    public Aluno aluno(@PathVariable String uuid){
        return this.service.getAlunoUUID(uuid);
    }
    /*
   http://localhost:8080/avaliador-de-projetos/aluno/uuid/edddd513-9ecd-45ac-8387-16256eae723a
   */
    @PutMapping("/uuid")
    public void atualizarUUID(@RequestBody Aluno aluno){
        this.service.autalizarUUID(aluno);
    }
}








