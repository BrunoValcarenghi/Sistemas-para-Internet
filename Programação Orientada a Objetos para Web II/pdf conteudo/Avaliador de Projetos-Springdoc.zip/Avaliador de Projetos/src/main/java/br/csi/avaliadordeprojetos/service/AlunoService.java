package br.csi.avaliadordeprojetos.service;

import br.csi.avaliadordeprojetos.model.aluno.Aluno;
import br.csi.avaliadordeprojetos.model.aluno.AlunoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class AlunoService {

    private final AlunoRepository repository;

    public AlunoService(AlunoRepository repository) {
        this.repository = repository;
    }
    public void salvar(Aluno aluno) {
        this.repository.save(aluno);
    }
    public List<Aluno> listar() {
        return this.repository.findAll();
    }
    public Aluno getAluno(Long id) {
        return this.repository.findById(id).get();
    }
    public void excluir(Long id){
        this.repository.deleteById(id);
    }
    /*
        Para atualizar uma entidade do banco é necessário pegar a referência desta
        entidade e atulizar com os dados que vieram por parametro.
        O save(...) detecta que esse RECURSO já existe no banco de dados pela busca por id
        assim ao executar o save com id ele faz um UPDATE
    * */
    public void autalizar(Aluno aluno){
        Aluno a = this.repository.getReferenceById(aluno.getId());
        a.setNome(aluno.getNome());
        a.setEmail(aluno.getEmail());
        a.setMatricula(aluno.getMatricula());
        a.setEndereco(aluno.getEndereco());
        this.repository.save(a);
    }

    public void autalizarUUID(Aluno aluno){
        Aluno a = this.repository.findAlunoByUuid(aluno.getUuid());
        a.setNome(aluno.getNome());
        a.setEmail(aluno.getEmail());
        a.setMatricula(aluno.getMatricula());
        a.setEndereco(aluno.getEndereco());
        this.repository.save(a);
    }
    public Aluno getAlunoUUID(String uuid) {
        UUID uuidformatado = UUID.fromString(uuid);
        return this.repository.findAlunoByUuid(uuidformatado);
    }
    public void deletarUUID(String uuid){
        this.repository.deleteAlunoByUuid(UUID.fromString(uuid));
    }
}






